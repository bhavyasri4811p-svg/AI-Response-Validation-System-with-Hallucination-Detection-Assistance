import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { EvaluationResult, EvaluationInput, AppSettings, EvaluationMetrics } from '../types';

export type EvaluationStage = 'idle' | 'analyzing' | 'correctness' | 'hallucination' | 'computing' | 'generating' | 'complete';

export interface StageInfo {
  stage: EvaluationStage;
  label: string;
  progress: number;
}

interface EvaluationContextType {
  currentEvaluation: EvaluationResult | null;
  history: EvaluationResult[];
  settings: AppSettings;
  isEvaluating: boolean;
  currentStage: StageInfo;
  evaluate: (input: EvaluationInput) => Promise<void>;
  clearCurrentEvaluation: () => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  deleteFromHistory: (id: string) => void;
}

const EvaluationContext = createContext<EvaluationContextType | undefined>(undefined);

const stages: StageInfo[] = [
  { stage: 'analyzing', label: 'Analyzing Response...', progress: 10 },
  { stage: 'correctness', label: 'Checking Correctness...', progress: 30 },
  { stage: 'hallucination', label: 'Detecting Hallucinations...', progress: 50 },
  { stage: 'computing', label: 'Computing Scores...', progress: 70 },
  { stage: 'generating', label: 'Generating Report...', progress: 90 },
  { stage: 'complete', label: 'Complete!', progress: 100 },
];

const generateMockEvaluation = (input: EvaluationInput): EvaluationResult => {
  // Calculate metrics based on input characteristics
  const responseWords = input.aiResponse.trim().split(/\s+/).length;
  const responseChars = input.aiResponse.trim().length;
  const questionWords = input.question.trim().split(/\s+/).length;
  const sentences = (input.aiResponse.match(/[.!?]+/g) || []).length || 1;
  const hasReferenceAnswer = input.referenceAnswer && input.referenceAnswer.trim().length > 0;
  const hasSourceDocument = input.sourceDocument !== null && input.sourceDocument !== undefined;

  // Categorize response length
  const isShortResponse = responseWords < 20;
  const isMediumResponse = responseWords >= 20 && responseWords < 100;
  const isLongResponse = responseWords >= 100;

  // Calculate completeness based on response length and detail
  let completeness: number;
  if (isShortResponse) {
    completeness = Math.min(45 + Math.floor(responseWords * 0.5), 55);
  } else if (isMediumResponse) {
    completeness = Math.min(60 + Math.floor((responseWords - 20) * 0.3), 80);
  } else {
    completeness = Math.min(80 + Math.min(Math.floor((responseWords - 100) * 0.1), 15), 95);
  }

  // Calculate fluency based on sentence structure
  const avgWordsPerSentence = responseWords / sentences;
  let fluency: number;
  if (avgWordsPerSentence < 5 || avgWordsPerSentence > 40) {
    fluency = 70 + Math.floor(Math.random() * 10);
  } else if (avgWordsPerSentence >= 10 && avgWordsPerSentence <= 25) {
    fluency = 90 + Math.floor(Math.random() * 8);
  } else {
    fluency = 80 + Math.floor(Math.random() * 10);
  }

  // Calculate correctness - higher if has reference answer to compare
  let correctness: number;
  if (hasReferenceAnswer) {
    correctness = 85 + Math.floor(Math.random() * 10);
  } else if (isLongResponse) {
    correctness = 75 + Math.floor(Math.random() * 15);
  } else if (isMediumResponse) {
    correctness = 70 + Math.floor(Math.random() * 20);
  } else {
    correctness = 60 + Math.floor(Math.random() * 20);
  }

  // Calculate relevance based on keyword overlap and length ratio
  const questionKeywords = input.question.toLowerCase().split(/\s+/).filter(w => w.length > 3);
  const responseLower = input.aiResponse.toLowerCase();
  const keywordOverlap = questionKeywords.filter(kw => responseLower.includes(kw)).length;
  const keywordMatchRatio = questionKeywords.length > 0 ? keywordOverlap / questionKeywords.length : 0.5;

  let relevance: number;
  if (keywordMatchRatio > 0.7) {
    relevance = 85 + Math.floor(Math.random() * 12);
  } else if (keywordMatchRatio > 0.4) {
    relevance = 75 + Math.floor(Math.random() * 10);
  } else {
    relevance = 65 + Math.floor(Math.random() * 15);
  }

  // Calculate faithfulness - higher if source document provided
  let faithfulness: number;
  if (hasSourceDocument) {
    faithfulness = 80 + Math.floor(Math.random() * 15);
  } else if (hasReferenceAnswer) {
    faithfulness = 75 + Math.floor(Math.random() * 15);
  } else {
    // Without source, we can't verify faithfulness well
    faithfulness = isLongResponse ? 70 + Math.floor(Math.random() * 10) : 60 + Math.floor(Math.random() * 15);
  }

  // Calculate hallucination risk based on response characteristics
  let hallucinationRisk: number;
  if (isShortResponse) {
    // Very short responses may hallucinate due to lack of context
    hallucinationRisk = 45 + Math.floor(Math.random() * 25);
  } else if (hasSourceDocument || hasReferenceAnswer) {
    // Lower risk when we can verify against sources
    hallucinationRisk = 10 + Math.floor(Math.random() * 20);
  } else if (isLongResponse) {
    // Long responses without sources have some risk
    hallucinationRisk = 20 + Math.floor(Math.random() * 30);
  } else {
    hallucinationRisk = 25 + Math.floor(Math.random() * 25);
  }

  // Determine hallucination level
  const hallucinationLevel: 'Low' | 'Medium' | 'High' =
    hallucinationRisk < 30 ? 'Low' : hallucinationRisk < 50 ? 'Medium' : 'High';

  // Calculate overall score
  const overallScore = Math.round(
    (correctness + relevance + faithfulness + completeness + fluency) / 5
  );

  const metrics: EvaluationMetrics = {
    correctness,
    relevance,
    faithfulness,
    completeness,
    fluency,
    hallucinationRisk,
    overallScore,
  };

  // Generate contextual suggestions
  const suggestions: string[] = [];

  if (correctness >= 85) {
    suggestions.push('Response demonstrates strong factual accuracy.');
  } else if (correctness >= 70) {
    suggestions.push('Response is mostly correct but may need verification.');
  } else {
    suggestions.push('Verify factual accuracy of claims made.');
  }

  if (completeness >= 80) {
    suggestions.push('Response provides comprehensive coverage of the topic.');
  } else if (completeness >= 60) {
    suggestions.push('Consider adding more details to fully address the question.');
  } else {
    suggestions.push('Significant improvement needed in completeness.');
  }

  if (faithfulness >= 80) {
    suggestions.push('Response stays faithful to provided context.');
  } else {
    suggestions.push('Add supporting evidence from reliable sources.');
  }

  if (hallucinationLevel === 'Low') {
    suggestions.push('No significant hallucination detected.');
  } else if (hallucinationLevel === 'Medium') {
    suggestions.push('Some claims may need verification against sources.');
  } else {
    suggestions.push('High hallucination risk - cross-verify all claims.');
  }

  if (relevance >= 85) {
    suggestions.push('Response is highly relevant to the question asked.');
  } else {
    suggestions.push('Improve alignment with the specific question asked.');
  }

  // Generate recommendations
  const recommendations: string[] = [];

  if (fluency < 85) {
    recommendations.push('Consider improving sentence structure for better readability.');
  }
  if (completeness < 75) {
    recommendations.push('Add more detailed explanations to cover the topic fully.');
  }
  if (hallucinationRisk > 30) {
    recommendations.push('Cross-verify claims with authoritative source documents.');
  }
  if (relevance < 80) {
    recommendations.push('Ensure the response directly addresses all parts of the question.');
  }
  if (!hasSourceDocument && !hasReferenceAnswer) {
    recommendations.push('Providing a reference answer or source document improves evaluation accuracy.');
  }
  recommendations.push('Consider adding citations for factual claims.');

  return {
    id: `eval-${Date.now()}`,
    question: input.question,
    aiResponse: input.aiResponse,
    referenceAnswer: input.referenceAnswer || 'Not provided',
    sourceDocument: input.sourceDocument?.name,
    metrics,
    hallucinationLevel,
    suggestions,
    recommendations: recommendations.length > 0 ? recommendations : ['Response meets quality standards.'],
    evaluatedAt: new Date(),
  };
};

export function EvaluationProvider({ children }: { children: ReactNode }) {
  const [currentEvaluation, setCurrentEvaluation] = useState<EvaluationResult | null>(null);
  const [history, setHistory] = useState<EvaluationResult[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    darkMode: true,
    framework: 'RAGAS',
  });
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [currentStage, setCurrentStage] = useState<StageInfo>({ stage: 'idle', label: '', progress: 0 });

  const evaluate = useCallback(async (input: EvaluationInput) => {
    setIsEvaluating(true);
    setCurrentStage(stages[0]);

    // Animate through stages
    for (let i = 0; i < stages.length - 1; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800));
      setCurrentStage(stages[i]);
    }

    // Generate result at final stage
    await new Promise((resolve) => setTimeout(resolve, 600));
    setCurrentStage(stages[stages.length - 1]);

    // Small delay before showing results
    await new Promise((resolve) => setTimeout(resolve, 400));

    const result = generateMockEvaluation(input);
    setCurrentEvaluation(result);
    setHistory((prev) => [result, ...prev]);
    setIsEvaluating(false);
    setCurrentStage({ stage: 'idle', label: '', progress: 0 });
  }, []);

  const clearCurrentEvaluation = useCallback(() => {
    setCurrentEvaluation(null);
  }, []);

  const updateSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  const deleteFromHistory = useCallback((id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  }, []);

  return (
    <EvaluationContext.Provider
      value={{
        currentEvaluation,
        history,
        settings,
        isEvaluating,
        currentStage,
        evaluate,
        clearCurrentEvaluation,
        updateSettings,
        deleteFromHistory,
      }}
    >
      {children}
    </EvaluationContext.Provider>
  );
}

export function useEvaluation() {
  const context = useContext(EvaluationContext);
  if (!context) {
    throw new Error('useEvaluation must be used within an EvaluationProvider');
  }
  return context;
}
